chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    // Retrieve the stored URLs from Chrome storage
    chrome.storage.sync.get(['sourceUrl', 'destinationUrl'], function(result) {
      const sourceUrl = result.sourceUrl;
      const destinationUrl = result.destinationUrl;

      if (sourceUrl && destinationUrl && details.url.includes(sourceUrl)) {
        return {redirectUrl: destinationUrl};
      }
    });
  },
  {urls: ["<all_urls>"]},
  ["blocking"]
);
