document.getElementById('save').addEventListener('click', function() {
  const source = document.getElementById('source').value;
  const destination = document.getElementById('destination').value;

  if (source && destination) {
    // Save source and destination URLs in Chrome storage
    chrome.storage.sync.set({sourceUrl: source, destinationUrl: destination}, function() {
      alert('Redirection saved!');
    });
  } else {
    alert('Please enter both URLs.');
  }
});
